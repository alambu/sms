<label class="control-label col-sm-12"> To </label>
<div class="form-group">
<label class="control-label col-sm-6">try to work </label>
</div>